// Tambo rules
