// Physics calculations
