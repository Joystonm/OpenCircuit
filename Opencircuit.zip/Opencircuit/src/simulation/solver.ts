// Circuit solver
