// Circuit detectors
