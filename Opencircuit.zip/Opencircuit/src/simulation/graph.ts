// Graph utilities
