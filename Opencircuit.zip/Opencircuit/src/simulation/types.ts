// Simulation types
