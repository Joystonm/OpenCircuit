import React from 'react';

export const Battery: React.FC = () => {
  return <div>Battery</div>;
};
