import React from 'react';

export const Bulb: React.FC = () => {
  return <div>Bulb</div>;
};
