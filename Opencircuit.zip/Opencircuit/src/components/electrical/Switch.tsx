import React from 'react';

export const Switch: React.FC = () => {
  return <div>Switch</div>;
};
