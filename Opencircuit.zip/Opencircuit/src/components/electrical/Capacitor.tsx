import React from 'react';

export const Capacitor: React.FC = () => {
  return <div>Capacitor</div>;
};
