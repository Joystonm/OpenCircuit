import React from 'react';

export const Resistor: React.FC = () => {
  return <div>Resistor</div>;
};
