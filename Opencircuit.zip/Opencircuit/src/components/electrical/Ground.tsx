import React from 'react';

export const Ground: React.FC = () => {
  return <div>Ground</div>;
};
