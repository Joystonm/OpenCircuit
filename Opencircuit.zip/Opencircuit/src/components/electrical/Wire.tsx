import React from 'react';

export const Wire: React.FC = () => {
  return <div>Wire</div>;
};
