import React from 'react';

export const LED: React.FC = () => {
  return <div>LED</div>;
};
