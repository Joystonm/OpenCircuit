import React from 'react';

export const ContextBadge: React.FC = () => {
  return <div>ContextBadge</div>;
};
