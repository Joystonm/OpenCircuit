import React from 'react';

export const Draggable: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return <div>{children}</div>;
};
