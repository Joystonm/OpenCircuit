import React from 'react';

export const HeatMapOverlay: React.FC = () => {
  return <div>HeatMapOverlay</div>;
};
